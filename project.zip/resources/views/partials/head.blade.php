<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

@php($applicationName = __('Osun Marketing Directory'))

<title>
    {{ filled($title ?? null) && $title !== $applicationName ? $title.' - '.$applicationName : $applicationName }}
</title>

<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

@fonts

@vite(['resources/css/app.css', 'resources/js/app.js'])
@fluxAppearance
